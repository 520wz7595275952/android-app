# 提示词图片管理器

一个Android应用，用于存储和管理图片及其对应的AI提示词。

## 功能特点

1. **图片存储** - 存储图片到应用私有目录，不会出现在系统相册中
2. **提示词管理** - 为每张图片添加、编辑和复制对应的提示词
3. **图片分类** - 支持创建分类，对图片进行分组管理
4. **搜索功能** - 支持按提示词内容搜索图片
5. **分享接收** - 可以从其他应用（如浏览器）分享图片到本应用
6. **一键复制** - 快速复制提示词到剪贴板

## 技术栈

- Kotlin
- Android SDK 34
- Room 数据库
- Glide 图片加载
- Material Design 3

## 项目结构

```
app/src/main/java/com/promptimagemanager/
├── data/                    # 数据层
│   ├── AppDatabase.kt       # Room数据库
│   ├── Category.kt          # 分类数据类
│   ├── CategoryDao.kt       # 分类DAO
│   ├── ImageDao.kt          # 图片DAO
│   ├── ImageItem.kt         # 图片数据类
│   ├── ImageWithCategory.kt # 关联数据类
│   └── Repository.kt        # 数据仓库
├── adapter/                 # 适配器
│   ├── CategoryAdapter.kt   # 分类列表适配器
│   ├── ImageAdapter.kt      # 图片列表适配器
│   └── ShareImageAdapter.kt # 分享图片适配器
├── ui/                      # UI层
│   ├── MainActivity.kt      # 主界面
│   ├── AddImageActivity.kt  # 添加图片
│   ├── ImageDetailActivity.kt # 图片详情
│   ├── CategoryActivity.kt  # 分类管理
│   └── ShareReceiverActivity.kt # 接收分享
└── utils/                   # 工具类
    ├── ClipboardHelper.kt   # 剪贴板工具
    └── ImageStorageManager.kt # 图片存储管理
```

## 构建说明

### 方法一：使用 Android Studio（推荐）

1. 下载并安装 [Android Studio](https://developer.android.com/studio)
2. 打开 Android Studio，选择 "Open an existing Android Studio project"
3. 选择本项目文件夹
4. 等待 Gradle 同步完成
5. 连接 Android 设备或启动模拟器
6. 点击 "Run" 按钮（绿色三角形）或按 Shift+F10

### 方法二：使用命令行

需要安装：
- JDK 17 或更高版本
- Android SDK
- Gradle 8.2

```bash
# 进入项目目录
cd PromptImageManager

# 给予 gradlew 执行权限
chmod +x gradlew

# 下载依赖并构建 APK
./gradlew assembleDebug

# APK 输出路径
app/build/outputs/apk/debug/app-debug.apk
```

## 安装说明

构建完成后，可以通过以下方式安装：

```bash
# 使用 adb 安装
adb install app/build/outputs/apk/debug/app-debug.apk
```

或直接传输到手机安装。

## 使用说明

### 添加图片
1. 点击右下角的 "+" 按钮
2. 选择 "从相册选择"
3. 选择要添加的图片
4. 输入提示词（可选）
5. 选择分类（可选）
6. 点击保存

### 从其他应用分享图片
1. 在其他应用（如浏览器）中打开图片
2. 点击分享按钮
3. 选择 "提示词图片管理"
4. 输入提示词和选择分类
5. 点击保存

### 管理分类
1. 点击右上角菜单，选择 "分类"
2. 点击右下角 "+" 添加新分类
3. 点击分类可查看该分类下的图片
4. 点击删除图标可删除分类

### 复制提示词
- 在图片列表中，点击 "复制提示词" 按钮
- 或在图片详情页点击 "复制" 按钮

## 隐私说明

所有图片都存储在应用的私有目录中，不会出现在系统相册或其他应用中。数据完全本地存储，不会上传到任何服务器。

## 许可证

MIT License
